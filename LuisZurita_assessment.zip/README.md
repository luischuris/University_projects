# How to run

The program is called nanprogram.java it receives 2 parameters one for input
and one for output input must be csv, it was written using java7, and compiled
with javac it should work for every input with 1 or more lines.
The Junit test class was not developed due to the time limitation but I tested it
with some values and recorded the detailed expected output on the test file for
future modifications.  
example:

-javac nanprogram.java
java nanprogram input_test_data.csv  output.csv

more information is given in the header of the java document, but I will paste it
here if needed

//By Luis Zurita, 23/05/2019
//This program receives a csv document with some values "nan", and they are
//systematically replaced for the average of the values around that except for
//the diagonals, this means that after a "nan" is replaced with a number adjacent
//nans will take into account the new value. it catches and report some errors,but
//it has not been fully tested.
//I required 3 hours and 45 minutes, the expected were 3 hours but I had some problems deciding
//the number of decimals printed in the output.. there are some comments about it



# Extras (both were tried)

If you complete the task in less than three hours, consider adding the following
additional requirements in the remaining time:
  - Exit gracefully and with user-friendly error messages when malformed input is
    provided.
  - Handle adjacent missing values (the choice of how to interpolate in this
    case is left to you).

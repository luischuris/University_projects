//By Luis Zurita, 23/05/2019
//This program receives a csv document with some values "nan", and they are
//systematically replaced for the average of the values around that except for
//the diagonals, this means that after a "nan" is replaced with a number adjacent
//nans will take into account the new value. it catches and report some errors,but
//it has not been fully tested.
//I required 3 hours and 45 minutes, the expected were 3 hours but I had some problems deciding
//the number of decimals printed in the output.. there are some comments about it

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;


public class nanprogram
{
  public static void main(String[] args)
  {
    //set input and output
    BufferedReader input = null;
    PrintWriter output = null;
    String non_number = "nan";

    try
  	{
      //check it has 2 parameters
      if(args.length != 2)
   	    throw new IllegalArgumentException
                 ("It must be provided exactly 2 arguments: input_file_path output_file_name");

      input = new BufferedReader(new FileReader(args[0]));
      output = new PrintWriter(new FileWriter(args[1]));

      String currentLine;
      String[] currentLine_elements;
      String[][] everyLine;
      int lineIndex = 0;
      int numberOfElements;
      //ArrayList<String> everyLine = new ArrayList<String>();
      //I though about using arraylists but decided to stay with regular arrays

      //checks it is not empty
      if((currentLine = input.readLine())!= null)
      {
        //divide the line
        currentLine_elements = currentLine.split(",");
        //gt number of elements to create the 2d array
        numberOfElements = currentLine_elements.length;
        everyLine = new String[numberOfElements][numberOfElements];
        //store the first array of elements into the 2d array
        everyLine[lineIndex] = currentLine_elements;
        //keep track of the index
        lineIndex++;
      }
      else
      {
        throw new IllegalArgumentException("Input file is empty");
      }
      //if there is any inconsistency on the 2d array size, it will produce an
      //index out of bound exception.
      while((currentLine = input.readLine()) != null)
      {
        currentLine_elements = currentLine.split(",");
        everyLine[lineIndex] = currentLine_elements;
        lineIndex++;
      }//while

      for(int rows = 0; rows < numberOfElements; rows++)
      {
        for(int columns = 0; columns < numberOfElements; columns++)
        {
          //check for Null
          if(everyLine[rows][columns].equals(non_number))
            replace_nan(rows,columns,numberOfElements,everyLine);
          //the string is casted into a double in order to make decimals follow
          //a format of 6 decimal numbers in the output,this could be changed for
          //to get more precision
          if(columns != numberOfElements-1)
            output.printf("%.6f,",Double.parseDouble(everyLine[rows][columns]));
          else
            output.printf("%.6f\n", Double.parseDouble(everyLine[rows][columns]));
        }
      }


  	}//try
    catch(IllegalArgumentException e)
    {
      System.out.println("Input file is empty");
      throw e; // rethrowing the exception
    }
    catch(ArithmeticException e)
    {
      System.out.println("It was not possible to assign a value to a nan");
      throw e; // rethrowing the exception
    }
  	catch(Exception exception)
    {
   	  System.err.println(exception);
    }

    finally
    {
    	 try
       {
         if(input != null)
           input.close();
       }
    	 catch (IOException exception)
    	 {
         System.err.println("Could not close input "+ exception);
       }
       if(output != null)
       {
         output.close();
         if(output.checkError())
           System.err.println("Something went wrong with the output");
       }//if
    }//finally

  }//main




  public static void replace_nan(int row, int column, int number_elements, String[][] everyLine)
  {
    double numberOfNeighbours = 0; //neighbours per nan
    double acc = 0.0;              //sum of the neighbours

    //if it is not on the first row then it can check the value from above
    if(row != 0 && everyLine[row-1][column].equals("nan") == false)
    {
      numberOfNeighbours++;
      acc =  acc + Double.parseDouble(everyLine[row-1][column]);
    }

    //if it is not on the last row then it can check the value from below
    if(row != number_elements-1 && everyLine[row+1][column].equals("nan") == false )
    {
      numberOfNeighbours++;
      acc =  acc + Double.parseDouble(everyLine[row+1][column]);
    }

    //if it is not on the first column then it can check the value from the left
    if(column != 0 && everyLine[row][column-1].equals("nan") == false )
    {
      numberOfNeighbours++;
      acc =  acc + Double.parseDouble(everyLine[row][column-1]);
    }

    //if it is not on the last column then it can check the value from the right
    if(column != number_elements-1 && everyLine[row][column+1].equals("nan") == false )
    {
      numberOfNeighbours++;
      acc =  acc + Double.parseDouble(everyLine[row][column+1]);
    }
    //if all neighbours are nan
    if(numberOfNeighbours != 0)
    {
      acc = acc/numberOfNeighbours;
      everyLine[row][column] = String.valueOf(acc);
    }
    else
      throw new ArithmeticException("it is not possible to assign a value for nan in position " +
                                    row +", "+ column);

  }//extra method

}//class
